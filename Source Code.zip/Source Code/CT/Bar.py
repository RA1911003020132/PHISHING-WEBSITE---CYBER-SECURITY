import matplotlib.pyplot as plt;

import numpy as np
import matplotlib.pyplot as plt
from DBConnection import DBConnection

class Bar:
    @staticmethod
    def main():

        objects = ('Naive','SVM', 'ELM')
        y_pos = np.arange(len(objects))
        database = DBConnection.getConnection()
        cursor = database.cursor()
        cursor.execute("select * from eval")
        row = cursor.fetchall()
        performance=[]
        for r in row:
            print("1")
            performance.append(r[0])
            performance.append(r[1])
            performance.append(r[2])


        print(performance)
        plt.bar(y_pos, performance, align='center', alpha=0.5)
        plt.xticks(y_pos, objects)
        plt.ylabel('%')
        plt.title('Performance of Naive, ANN and SVM')

        plt.show()

if __name__=="__main__":
    Bar.main()


