# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'E:\QT\phishing\userhome.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from urlaction import URLCheck
from Prediction import predict_elm

class UserHome(object):

    def geturl(self):
        try:
            print("url")
            urlvar = self.url.text()
            print("url=",urlvar)

            #self.url.setText("")
            u=URLCheck()
            res= u.validation(urlvar)
            #print(res)
            if res==True:
                self.process(urlvar)
            else:
                self.showAlertBox("Data Alert", "       Enter Valid URL     ")

        except Exception as e:
            print(e.args[0])
            tb = sys.exc_info()[2]
            print(tb.tb_lineno)

    def process(self, url):

        if URLCheck.ipaddress(url):
            f1 = 1
        else:
            f1 = 0
        # --------------------

        if URLCheck.favicon(url):
            f8 = 1
        else:
            f8 = 0
        # --------------------
        if URLCheck.extractPort(url):
            f9 = 0
        else:
            f9 = 1
        # --------------------
        print("length of url==" , len(url))
        if len(url)>54:

            f2=1
        else:f2=0
        # --------------------
        if url.find('@') == -1:
            f3 = 0
        else:
            f3 = 1
        # --------------------
        if url.count('//') > 7:
            f4 = 0
        else:
            f4 = 1
        # --------------------
        if url.find('-') == -1:
            f5 = 0
        else:
            f5 = 1
        # --------------------
        if url.count('.') > 1:
            f6 = 0
        else:
            f6 = 1
        # --------------------
        if url.find('https') ==-1:
            f10 = 0
        else:
            f10 = 1
        # --------------------
        if url.find('mailto') == -1:
            f15 = 0
        else:
            f15 = 1

        row1 = ["f1", "f2", "f3", "f4", "f5", "f6", "f8", "f9", "f10", "f15"]

        row=[f1,f2,f3,f4,f5,f6,f8,f9,f10,f15]

        print(row)

        import csv

        with open('test.csv', 'w') as csvFile:
            writer = csv.writer(csvFile)
            writer.writerow(row1)
            writer.writerow(row)

        csvFile.close()
        res=predict_elm()
        self.showAlertBox("Result", "       URL is     "+str(res))


    def showAlertBox(self, title, message):
        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Information)
        msgBox.setWindowTitle(title)
        msgBox.setText(message)
        msgBox.setStandardButtons(QtWidgets.QMessageBox.Ok)
        msgBox.exec_()



    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(763, 576)
        self.tabWidget = QtWidgets.QTabWidget(Dialog)
        self.tabWidget.setGeometry(QtCore.QRect(0, 0, 761, 581))
        self.tabWidget.setStyleSheet("background-color: rgb(85, 170, 255);")
        self.tabWidget.setObjectName("tabWidget")
        self.tab = QtWidgets.QWidget()
        self.tab.setObjectName("tab")
        self.label = QtWidgets.QLabel(self.tab)
        self.label.setGeometry(QtCore.QRect(30, 80, 331, 81))
        self.label.setStyleSheet("font: 16pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);")
        self.label.setObjectName("label")
        self.tabWidget.addTab(self.tab, "")
        self.tab_2 = QtWidgets.QWidget()
        self.tab_2.setObjectName("tab_2")
        self.label_2 = QtWidgets.QLabel(self.tab_2)
        self.label_2.setGeometry(QtCore.QRect(30, 100, 281, 41))
        self.label_2.setStyleSheet("font: 16pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);")
        self.label_2.setObjectName("label_2")
        self.url = QtWidgets.QLineEdit(self.tab_2)
        self.url.setGeometry(QtCore.QRect(30, 160, 501, 31))
        self.url.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.url.setObjectName("url")
        self.prediction = QtWidgets.QPushButton(self.tab_2)
        self.prediction.setGeometry(QtCore.QRect(550, 160, 110, 30))
        self.prediction.setStyleSheet("color: rgb(255, 255, 255);\n"
"font: 12pt \"MS Shell Dlg 2\";")
        self.prediction.setObjectName("prediction")

        ######################3
        self.prediction.clicked.connect(self.geturl)
        #################

        self.tabWidget.addTab(self.tab_2, "")

        self.retranslateUi(Dialog)
        self.tabWidget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.label.setText(_translate("Dialog", "Welcome User.."))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), _translate("Dialog", "Home"))
        self.label_2.setText(_translate("Dialog", "Enter URL for Prediction"))
        self.prediction.setText(_translate("Dialog", "Prediction"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), _translate("Dialog", "Prediction"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = UserHome()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

