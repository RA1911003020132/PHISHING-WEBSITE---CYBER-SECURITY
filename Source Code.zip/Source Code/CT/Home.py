from PyQt5 import QtCore, QtGui, QtWidgets
import sys
from AdminLogin import AdminLogin
from UserLogin import UserLogin

class Home(object):

    def adminlogin(self, event):
        print("admin")
        self.al = QtWidgets.QDialog()
        self.ui = AdminLogin(self.al)
        self.ui.setupUi(self.al)
        self.al.show()
        event.accept()

    def userlogin(self, event):
        try:
            print("user")
            self.aul = QtWidgets.QDialog()
            self.uai =UserLogin(self.aul)
            self.uai.setupUi(self.aul)
            self.aul.show()
            event.accept()
        except Exception as e:
            print(e.args[0])
            tb = sys.exc_info()[2]
            print(tb.tb_lineno)

    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(679, 542)
        Dialog.setStyleSheet("image: url(../images/Phishing-attack.jpg);\n"
"")
        self.adminlogo = QtWidgets.QLabel(Dialog)
        self.adminlogo.setGeometry(QtCore.QRect(140, 230, 181, 141))
        self.adminlogo.setStyleSheet("image: url(../images/admin.png);")
        self.adminlogo.setText("")
        self.adminlogo.setObjectName("adminlogo")

        self.adminlogo.mousePressEvent = self.adminlogin

        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(206, 370, 61, 21))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(436, 370, 61, 21))
        self.label_2.setObjectName("label_2")
        self.userlogo = QtWidgets.QLabel(Dialog)
        self.userlogo.setGeometry(QtCore.QRect(390, 230, 131, 140))
        self.userlogo.setStyleSheet("image: url(../images/user.png);")
        self.userlogo.setText("")
        self.userlogo.setObjectName("userlogo")
        self.userlogo.mousePressEvent = self.userlogin


        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.label.setText(_translate("Dialog", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#ffffff;\">Admin</span></p></body></html>"))
        self.label_2.setText(_translate("Dialog", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#fcfcfc;\">User</span></p></body></html>"))

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Home()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

