# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'E:\QT\phishing\adminhome.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import sys
import xlrd
from DBConnection import DBConnection
from NaiveHome import NaiveHome
from SVMHome import SVMHome
from ELM import ELMHome
from Bar import Bar


class AdminHome(object):

    def viewgraphdef(self):
        try:
            Bar.main()

        except Exception as e:
            print(e.args[0])
            tb = sys.exc_info()[2]
            print(tb.tb_lineno)
            print(e)

    def niavecall(self):
        try:
            self.nu = QtWidgets.QDialog()
            self.nui = NaiveHome()
            self.nui.setupUi(self.nu)
            self.nu.show()


        except Exception as e:
            print(e.args[0])
            tb = sys.exc_info()[2]
            print(tb.tb_lineno)
            print(e)

    def svmcall(self):
        try:
            self.su = QtWidgets.QDialog()
            self.sui = SVMHome()
            self.sui.setupUi(self.su)
            self.su.show()


        except Exception as e:
            print(e.args[0])
            tb = sys.exc_info()[2]
            print(tb.tb_lineno)
            print(e)

    def elmcall(self):
        try:
            self.eu = QtWidgets.QDialog()
            self.eui = ELMHome()
            self.eui.setupUi(self.eu)
            self.eu.show()


        except Exception as e:
            print(e.args[0])
            tb = sys.exc_info()[2]
            print(tb.tb_lineno)
            print(e)

    def browsefile(self):
        try:
            fileName, _ = QtWidgets.QFileDialog.getOpenFileName(None, "Select File",
                                                                "E:\A PROJECTS\Python Projects\Phishing Web Sites Features Classification Based on Extreme Learning Machine",
                                                                "*.xlsx")
            print(fileName)
            self.lineEdit.setText(fileName)
        except Exception as e:
            print("Error=" + e.args[0])
            tb = sys.exc_info()[2]
            print(tb.tb_lineno)
            print(e)

    def uploadAction(self):
        try:
            fname = self.lineEdit.text()
            book = xlrd.open_workbook(fname)
            book = xlrd.open_workbook(fname)
            sheet = book.sheet_by_index(0)
            database = DBConnection.getConnection()
            cursor = database.cursor()
            cursor2 = database.cursor()
            cursor.execute("delete from dataset")
            database.commit()
            query = "insert into dataset values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            print(query)
            for r in range(1, sheet.nrows):
                f0 = sheet.cell(r, 0).value
                f1 = sheet.cell(r, 1).value
                f2 = sheet.cell(r, 2).value
                f3 = sheet.cell(r, 3).value
                f4 = sheet.cell(r, 4).value
                f5 = sheet.cell(r, 5).value
                f6 = sheet.cell(r, 6).value
                f7 = sheet.cell(r, 7).value
                f8 = sheet.cell(r, 8).value
                f9 = sheet.cell(r, 9).value
                f10 = sheet.cell(r, 10).value
                f11 = sheet.cell(r, 11).value
                f12 = sheet.cell(r, 12).value
                f13 = sheet.cell(r, 13).value
                f14 = sheet.cell(r, 14).value
                f15 = sheet.cell(r, 15).value
                f16 = sheet.cell(r, 16).value
                f17 = sheet.cell(r, 17).value
                f18 = sheet.cell(r, 18).value
                f19 = sheet.cell(r, 19).value
                f20 = sheet.cell(r, 20).value
                f21 = sheet.cell(r, 21).value
                f22 = sheet.cell(r, 22).value
                f23 = sheet.cell(r, 23).value
                f24 = sheet.cell(r, 24).value
                f25 = sheet.cell(r, 25).value
                f26 = sheet.cell(r, 26).value
                f27 = sheet.cell(r, 27).value
                f28 = sheet.cell(r, 28).value

                values = (
                    f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14, f15, f16, f17, f18, f19, f20, f21,
                    f22, f23, f24, f25, f26, f27, f28)
                # print(values)
                cursor.execute(query, values)
                database.commit()
                columns = str(sheet.ncols)
                # rows=str(sheet.nrows)
                print("inserted")
            self.showAlertBox("Information", "DataSet Loaded Successfully")
            self.lineEdit.setText("")
        except Exception as e:
            print("Error=" + e.args[0])
            tb = sys.exc_info()[2]
            print(tb.tb_lineno)
            print(e)

    def showAlertBox(self, title, message):
        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Information)
        msgBox.setWindowTitle(title)
        msgBox.setText(message)
        msgBox.setStandardButtons(QtWidgets.QMessageBox.Ok)
        msgBox.exec_()

    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(849, 573)
        self.Dataset = QtWidgets.QTabWidget(Dialog)
        self.Dataset.setGeometry(QtCore.QRect(0, 0, 851, 581))
        self.Dataset.setStyleSheet("background-color: rgb(85, 170, 255);")
        self.Dataset.setTabPosition(QtWidgets.QTabWidget.North)
        self.Dataset.setObjectName("Dataset")
        self.tab = QtWidgets.QWidget()
        self.tab.setObjectName("tab")
        self.label = QtWidgets.QLabel(self.tab)
        self.label.setGeometry(QtCore.QRect(60, 30, 531, 141))
        self.label.setStyleSheet("font: 18pt \"Gill Sans MT\";")
        self.label.setObjectName("label")
        self.Dataset.addTab(self.tab, "")
        self.tab_2 = QtWidgets.QWidget()
        self.tab_2.setObjectName("tab_2")
        self.label_2 = QtWidgets.QLabel(self.tab_2)
        self.label_2.setGeometry(QtCore.QRect(50, 130, 261, 61))
        self.label_2.setObjectName("label_2")
        self.datasetupload = QtWidgets.QPushButton(self.tab_2)
        self.datasetupload.setGeometry(QtCore.QRect(60, 270, 75, 30))
        self.datasetupload.setObjectName("datasetupload")

        ####################
        self.datasetupload.clicked.connect(self.uploadAction)
        ####################

        self.lineEdit = QtWidgets.QLineEdit(self.tab_2)
        self.lineEdit.setGeometry(QtCore.QRect(60, 230, 320, 30))
        self.lineEdit.setObjectName("lineEdit")
        self.datasetbrowse = QtWidgets.QPushButton(self.tab_2)
        self.datasetbrowse.setGeometry(QtCore.QRect(400, 230, 90, 30))
        self.datasetbrowse.setObjectName("datasetbrowse")
        #####################
        self.datasetbrowse.clicked.connect(self.browsefile)
        #####################
        self.Dataset.addTab(self.tab_2, "")
        self.tab_3 = QtWidgets.QWidget()
        self.tab_3.setObjectName("tab_3")
        self.naive = QtWidgets.QPushButton(self.tab_3)
        self.naive.setGeometry(QtCore.QRect(280, 160, 260, 30))
        self.naive.setStyleSheet("color: rgb(247, 247, 247);\n"
                                 "font: 12pt \"Franklin Gothic Heavy\";")
        self.naive.setObjectName("naive")
        ######################3
        self.naive.clicked.connect(self.niavecall)
        #################
        self.svm = QtWidgets.QPushButton(self.tab_3)
        self.svm.setGeometry(QtCore.QRect(280, 230, 260, 30))
        self.svm.setAutoFillBackground(False)
        self.svm.setStyleSheet("color: rgb(247, 247, 247);\n"
                               "font: 12pt \"Franklin Gothic Heavy\";")
        self.svm.setObjectName("svm")
        ######################3
        self.svm.clicked.connect(self.svmcall)
        #################
        self.elm = QtWidgets.QPushButton(self.tab_3)
        self.elm.setGeometry(QtCore.QRect(280, 300, 260, 30))
        self.elm.setStyleSheet("color: rgb(247, 247, 247);\n"
                               "font: 12pt \"Franklin Gothic Heavy\";")
        self.elm.setObjectName("elm")
        ######################3
        self.elm.clicked.connect(self.elmcall)
        #################
        self.label_3 = QtWidgets.QLabel(self.tab_3)
        self.label_3.setGeometry(QtCore.QRect(310, 30, 231, 61))
        self.label_3.setMinimumSize(QtCore.QSize(231, 0))
        self.label_3.setStyleSheet("font: 75 18pt \"Berlin Sans FB\";")
        self.label_3.setObjectName("label_3")
        self.Dataset.addTab(self.tab_3, "")
        self.tab_4 = QtWidgets.QWidget()
        self.tab_4.setObjectName("tab_4")
        self.viewgraph = QtWidgets.QPushButton(self.tab_4)
        self.viewgraph.setGeometry(QtCore.QRect(330, 120, 201, 241))
        self.viewgraph.setStyleSheet("\n"
                                     "border-image: url(1-512.png);")
        self.viewgraph.setText("")
        self.viewgraph.setObjectName("viewgraph")
        ######################3
        self.viewgraph.clicked.connect(self.viewgraphdef)
        #################
        self.Dataset.addTab(self.tab_4, "")

        self.retranslateUi(Dialog)
        self.Dataset.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.label.setText(_translate("Dialog",
                                      "<html><head/><body><p><span style=\" font-size:22pt; color:#ffffff;\">Welcome Admin</span></p></body></html>"))
        self.Dataset.setTabText(self.Dataset.indexOf(self.tab), _translate("Dialog", "Home"))
        self.label_2.setText(_translate("Dialog",
                                        "<html><head/><body><p><span style=\" font-size:16pt; font-weight:600; color:#f4faff;\">Upload DataSet</span></p></body></html>"))
        self.datasetupload.setText(_translate("Dialog", "Upload"))
        self.datasetbrowse.setText(_translate("Dialog", "Browse"))
        self.Dataset.setTabText(self.Dataset.indexOf(self.tab_2), _translate("Dialog", "Upload Dataset"))
        self.naive.setText(_translate("Dialog", "Naïve Bayes"))
        self.svm.setText(_translate("Dialog", "Support Vector Machine"))
        self.elm.setText(_translate("Dialog", "Extreme Learning Machine"))
        self.label_3.setText(_translate("Dialog",
                                        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
                                        "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
                                        "p, li { white-space: pre-wrap; }\n"
                                        "</style></head><body style=\" font-family:\'Berlin Sans FB\'; font-size:18pt; font-weight:72; font-style:normal;\">\n"
                                        "<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'MS Shell Dlg 2\'; font-size:26pt; font-weight:600; color:#fafafa; vertical-align:sub;\">Classifications</span></p></body></html>"))
        self.Dataset.setTabText(self.Dataset.indexOf(self.tab_3), _translate("Dialog", "Classifications"))
        self.Dataset.setTabText(self.Dataset.indexOf(self.tab_4), _translate("Dialog", "Performance"))




if __name__ == "__main__":
    import sys

    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = AdminHome()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

