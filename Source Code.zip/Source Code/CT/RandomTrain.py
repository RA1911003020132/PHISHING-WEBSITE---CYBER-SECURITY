# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'E:\QT\phishing\niave.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from DBConnection import DBConnection
from sklearn.neural_network import MLPClassifier

import numpy as np
import pandas as pd
import sys
import time
from sklearn import metrics
import pickle

from sklearn.ensemble import RandomForestClassifier


class RandomTrain(object):

    def training(self):
        try:
            trainset = []
            # testset=[float('0'), float('1'), float('1'),float('1'),float('0'),float('0'),float('0'),float('1')]
            # testset=
            database = DBConnection.getConnection()
            cursor = database.cursor()
            cursor.execute(
                "select * from dataset")
            row = cursor.fetchall()
            y_train = []
            trainset.clear()
            y_train.clear()
            train=len(row)
            for r in row:

                x_train = []
                x_train.clear()
                x_train.append(float(r[0]))
                x_train.append(float(r[1]))
                x_train.append(float(r[2]))
                x_train.append(float(r[3]))
                x_train.append(float(r[4]))
                x_train.append(float(r[5]))
                x_train.append(float(r[6]))
                x_train.append(float(r[7]))
                x_train.append(float(r[8]))
                x_train.append(float(r[9]))
                x_train.append(float(r[10]))
                x_train.append(float(r[11]))
                x_train.append(float(r[12]))
                x_train.append(float(r[13]))
                x_train.append(float(r[14]))
                x_train.append(float(r[15]))
                x_train.append(float(r[16]))
                x_train.append(float(r[17]))
                x_train.append(float(r[18]))
                x_train.append(float(r[19]))
                x_train.append(float(r[20]))
                x_train.append(float(r[21]))
                x_train.append(float(r[22]))
                x_train.append(float(r[23]))
                x_train.append(float(r[24]))
                x_train.append(float(r[25]))
                x_train.append(float(r[26]))
                x_train.append(float(r[27]))
                y_train.append(r[28])
                trainset.append(x_train)
            print("y=", y_train)
            # print("trd=", trainset)
            trainset = np.array(trainset)
            print("trd=", trainset)
            # NaiveBayes Classifier

            # Train the model

            y_train = np.array(y_train)

            # print(res
            clf = RandomForestClassifier()
            clf.fit(trainset, y_train)

            # save the model to disk
            filename = 'finalized_model.sav'
            pickle.dump(clf, open(filename, 'wb'))
            print("Completed")

        except Exception as e:
            print("Error=" + e.args[0])
            tb = sys.exc_info()[2]
            print(tb.tb_lineno)

r=RandomTrain()
r.training()